#!/usr/bin/python
# Copyright (c) 2020, 2023 Oracle and/or its affiliates.
# This software is made available to you under the terms of the GPL 3.0 license or the Apache 2.0 license.
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)
# Apache License v2.0
# See LICENSE.TXT for details.
# GENERATED FILE - DO NOT EDIT - MANUAL CHANGES WILL BE OVERWRITTEN


from __future__ import absolute_import, division, print_function

__metaclass__ = type

ANSIBLE_METADATA = {
    "metadata_version": "1.1",
    "status": ["preview"],
    "supported_by": "community",
}

DOCUMENTATION = """
---
module: oci_compute_management_cluster_network_actions
short_description: Perform actions on a ClusterNetwork resource in Oracle Cloud Infrastructure
description:
    - Perform actions on a ClusterNetwork resource in Oracle Cloud Infrastructure
    - For I(action=change_compartment), moves a L(cluster network with instance
      pools,https://docs.cloud.oracle.com/iaas/Content/Compute/Tasks/managingclusternetworks.htm)
      into a different compartment within the same tenancy. For
      information about moving resources between compartments, see
      L(Moving Resources to a Different Compartment,https://docs.cloud.oracle.com/iaas/Content/Identity/Tasks/managingcompartments.htm#moveRes).
      When you move a cluster network to a different compartment, associated resources such as the instances
      in the cluster network, boot volumes, and VNICs are not moved.
version_added: "2.9.0"
author: Oracle (@oracle)
options:
    cluster_network_id:
        description:
            - The L(OCID,https://docs.cloud.oracle.com/iaas/Content/General/Concepts/identifiers.htm) of the cluster network.
        type: str
        aliases: ["id"]
        required: true
    compartment_id:
        description:
            - The L(OCID,https://docs.cloud.oracle.com/iaas/Content/General/Concepts/identifiers.htm) of the compartment
              into which the resource should be moved.
        type: str
        required: true
    action:
        description:
            - The action to perform on the ClusterNetwork.
        type: str
        required: true
        choices:
            - "change_compartment"
extends_documentation_fragment: [ oracle.oci.oracle ]
"""

EXAMPLES = """
- name: Perform action change_compartment on cluster_network
  oci_compute_management_cluster_network_actions:
    # required
    cluster_network_id: "ocid1.clusternetwork.oc1..xxxxxxEXAMPLExxxxxx"
    compartment_id: "ocid1.compartment.oc1..xxxxxxEXAMPLExxxxxx"
    action: change_compartment

"""

RETURN = """
cluster_network:
    description:
        - Details of the ClusterNetwork resource acted upon by the current operation
    returned: on success
    type: complex
    contains:
        id:
            description:
                - The L(OCID,https://docs.cloud.oracle.com/iaas/Content/General/Concepts/identifiers.htm) of the cluster network.
            returned: on success
            type: str
            sample: "ocid1.resource.oc1..xxxxxxEXAMPLExxxxxx"
        compartment_id:
            description:
                - The L(OCID,https://docs.cloud.oracle.com/iaas/Content/General/Concepts/identifiers.htm) of the compartment containing the cluster network.
            returned: on success
            type: str
            sample: "ocid1.compartment.oc1..xxxxxxEXAMPLExxxxxx"
        hpc_island_id:
            description:
                - The L(OCID,https://docs.cloud.oracle.com/iaas/Content/General/Concepts/identifiers.htm) of the HPC island used by the cluster network.
            returned: on success
            type: str
            sample: "ocid1.hpcisland.oc1..xxxxxxEXAMPLExxxxxx"
        network_block_ids:
            description:
                - The list of network block OCIDs of the HPC island.
            returned: on success
            type: list
            sample: []
        defined_tags:
            description:
                - Defined tags for this resource. Each key is predefined and scoped to a
                  namespace. For more information, see L(Resource Tags,https://docs.cloud.oracle.com/iaas/Content/General/Concepts/resourcetags.htm).
                - "Example: `{\\"Operations\\": {\\"CostCenter\\": \\"42\\"}}`"
            returned: on success
            type: dict
            sample: {'Operations': {'CostCenter': 'US'}}
        display_name:
            description:
                - A user-friendly name. Does not have to be unique, and it's changeable.
                  Avoid entering confidential information.
            returned: on success
            type: str
            sample: display_name_example
        freeform_tags:
            description:
                - Free-form tags for this resource. Each tag is a simple key-value pair with no
                  predefined name, type, or namespace. For more information, see L(Resource
                  Tags,https://docs.cloud.oracle.com/iaas/Content/General/Concepts/resourcetags.htm).
                - "Example: `{\\"Department\\": \\"Finance\\"}`"
            returned: on success
            type: dict
            sample: {'Department': 'Finance'}
        instance_pools:
            description:
                - The instance pools in the cluster network.
                - Each cluster network can have one instance pool.
            returned: on success
            type: complex
            contains:
                id:
                    description:
                        - The L(OCID,https://docs.cloud.oracle.com/iaas/Content/General/Concepts/identifiers.htm) of the instance pool.
                    returned: on success
                    type: str
                    sample: "ocid1.resource.oc1..xxxxxxEXAMPLExxxxxx"
                compartment_id:
                    description:
                        - The L(OCID,https://docs.cloud.oracle.com/iaas/Content/General/Concepts/identifiers.htm) of the compartment containing the instance
                          pool.
                    returned: on success
                    type: str
                    sample: "ocid1.compartment.oc1..xxxxxxEXAMPLExxxxxx"
                defined_tags:
                    description:
                        - Defined tags for this resource. Each key is predefined and scoped to a
                          namespace. For more information, see L(Resource Tags,https://docs.cloud.oracle.com/iaas/Content/General/Concepts/resourcetags.htm).
                        - "Example: `{\\"Operations\\": {\\"CostCenter\\": \\"42\\"}}`"
                    returned: on success
                    type: dict
                    sample: {'Operations': {'CostCenter': 'US'}}
                display_name:
                    description:
                        - A user-friendly name. Does not have to be unique, and it's changeable.
                          Avoid entering confidential information.
                    returned: on success
                    type: str
                    sample: display_name_example
                freeform_tags:
                    description:
                        - Free-form tags for this resource. Each tag is a simple key-value pair with no
                          predefined name, type, or namespace. For more information, see L(Resource
                          Tags,https://docs.cloud.oracle.com/iaas/Content/General/Concepts/resourcetags.htm).
                        - "Example: `{\\"Department\\": \\"Finance\\"}`"
                    returned: on success
                    type: dict
                    sample: {'Department': 'Finance'}
                instance_configuration_id:
                    description:
                        - The L(OCID,https://docs.cloud.oracle.com/iaas/Content/General/Concepts/identifiers.htm) of the instance configuration associated
                          with the instance pool.
                    returned: on success
                    type: str
                    sample: "ocid1.instanceconfiguration.oc1..xxxxxxEXAMPLExxxxxx"
                lifecycle_state:
                    description:
                        - The current state of the instance pool.
                    returned: on success
                    type: str
                    sample: PROVISIONING
                placement_configurations:
                    description:
                        - The placement configurations for the instance pool.
                    returned: on success
                    type: complex
                    contains:
                        availability_domain:
                            description:
                                - The availability domain to place instances.
                                - "Example: `Uocm:PHX-AD-1`"
                            returned: on success
                            type: str
                            sample: Uocm:PHX-AD-1
                        primary_subnet_id:
                            description:
                                - The L(OCID,https://docs.cloud.oracle.com/iaas/Content/General/Concepts/identifiers.htm) of the primary subnet in which to
                                  place instances.
                            returned: on success
                            type: str
                            sample: "ocid1.primarysubnet.oc1..xxxxxxEXAMPLExxxxxx"
                        fault_domains:
                            description:
                                - The fault domains to place instances.
                                - If you don't provide any values, the system makes a best effort to distribute
                                  instances across all fault domains based on capacity.
                                - To distribute the instances evenly across selected fault domains, provide a
                                  set of fault domains. For example, you might want instances to be evenly
                                  distributed if your applications require high availability.
                                - To get a list of fault domains, use the
                                  L(ListFaultDomains,https://docs.cloud.oracle.com/en-us/iaas/api/#/en/identity/20160918/FaultDomain/ListFaultDomains) operation
                                  in the Identity and Access Management Service API.
                                - "Example: `[FAULT-DOMAIN-1, FAULT-DOMAIN-2, FAULT-DOMAIN-3]`"
                            returned: on success
                            type: list
                            sample: []
                        secondary_vnic_subnets:
                            description:
                                - The set of secondary VNIC data for instances in the pool.
                            returned: on success
                            type: complex
                            contains:
                                display_name:
                                    description:
                                        - The display name of the VNIC. This is also used to match against the instance configuration defined
                                          secondary VNIC.
                                    returned: on success
                                    type: str
                                    sample: display_name_example
                                subnet_id:
                                    description:
                                        - The subnet L(OCID,https://docs.cloud.oracle.com/iaas/Content/General/Concepts/identifiers.htm) for the secondary VNIC.
                                    returned: on success
                                    type: str
                                    sample: "ocid1.subnet.oc1..xxxxxxEXAMPLExxxxxx"
                size:
                    description:
                        - The number of instances that should be in the instance pool.
                    returned: on success
                    type: int
                    sample: 56
                time_created:
                    description:
                        - "The date and time the instance pool was created, in the format defined by L(RFC3339,https://tools.ietf.org/html/rfc3339).
                          Example: `2016-08-25T21:10:29.600Z`"
                    returned: on success
                    type: str
                    sample: "2013-10-20T19:20:30+01:00"
                load_balancers:
                    description:
                        - The load balancers attached to the instance pool.
                    returned: on success
                    type: complex
                    contains:
                        id:
                            description:
                                - The L(OCID,https://docs.cloud.oracle.com/iaas/Content/General/Concepts/identifiers.htm) of the load balancer attachment.
                            returned: on success
                            type: str
                            sample: "ocid1.resource.oc1..xxxxxxEXAMPLExxxxxx"
                        instance_pool_id:
                            description:
                                - The L(OCID,https://docs.cloud.oracle.com/iaas/Content/General/Concepts/identifiers.htm) of the instance pool of the load
                                  balancer attachment.
                            returned: on success
                            type: str
                            sample: "ocid1.instancepool.oc1..xxxxxxEXAMPLExxxxxx"
                        load_balancer_id:
                            description:
                                - The L(OCID,https://docs.cloud.oracle.com/iaas/Content/General/Concepts/identifiers.htm) of the load balancer attached to the
                                  instance pool.
                            returned: on success
                            type: str
                            sample: "ocid1.loadbalancer.oc1..xxxxxxEXAMPLExxxxxx"
                        backend_set_name:
                            description:
                                - The name of the backend set on the load balancer.
                            returned: on success
                            type: str
                            sample: backend_set_name_example
                        port:
                            description:
                                - The port value used for the backends.
                            returned: on success
                            type: int
                            sample: 56
                        vnic_selection:
                            description:
                                - "Indicates which VNIC on each instance in the instance pool should be used to associate with the load balancer.
                                  Possible values are \\"PrimaryVnic\\" or the displayName of one of the secondary VNICs on the instance configuration
                                  that is associated with the instance pool."
                            returned: on success
                            type: str
                            sample: vnic_selection_example
                        lifecycle_state:
                            description:
                                - The status of the interaction between the instance pool and the load balancer.
                            returned: on success
                            type: str
                            sample: ATTACHING
                instance_display_name_formatter:
                    description:
                        - A user-friendly formatter for the instance pool's instances. Instance displaynames follow the format.
                          The formatter does not retroactively change instance's displaynames, only instance displaynames in the future follow the format
                    returned: on success
                    type: str
                    sample: instance_display_name_formatter_example
                instance_hostname_formatter:
                    description:
                        - A user-friendly formatter for the instance pool's instances. Instance hostnames follow the format.
                          The formatter does not retroactively change instance's hostnames, only instance hostnames in the future follow the format
                    returned: on success
                    type: str
                    sample: instance_hostname_formatter_example
        placement_configuration:
            description:
                - ""
            returned: on success
            type: complex
            contains:
                availability_domain:
                    description:
                        - The availability domain to place instances.
                        - "Example: `Uocm:PHX-AD-1`"
                    returned: on success
                    type: str
                    sample: Uocm:PHX-AD-1
                placement_constraint:
                    description:
                        - The placement constraint when reserving hosts.
                    returned: on success
                    type: str
                    sample: SINGLE_TIER
                primary_subnet_id:
                    description:
                        - The L(OCID,https://docs.cloud.oracle.com/iaas/Content/General/Concepts/identifiers.htm) of the primary subnet to place
                          instances.
                    returned: on success
                    type: str
                    sample: "ocid1.primarysubnet.oc1..xxxxxxEXAMPLExxxxxx"
                secondary_vnic_subnets:
                    description:
                        - The set of secondary VNIC data for instances in the pool.
                    returned: on success
                    type: complex
                    contains:
                        display_name:
                            description:
                                - The display name of the VNIC. This is also used to match against the instance configuration defined
                                  secondary VNIC.
                            returned: on success
                            type: str
                            sample: display_name_example
                        subnet_id:
                            description:
                                - The subnet L(OCID,https://docs.cloud.oracle.com/iaas/Content/General/Concepts/identifiers.htm) for the secondary VNIC.
                            returned: on success
                            type: str
                            sample: "ocid1.subnet.oc1..xxxxxxEXAMPLExxxxxx"
        lifecycle_state:
            description:
                - The current state of the cluster network.
            returned: on success
            type: str
            sample: PROVISIONING
        time_created:
            description:
                - The date and time the resource was created, in the format defined by L(RFC3339,https://tools.ietf.org/html/rfc3339).
                - "Example: `2016-08-25T21:10:29.600Z`"
            returned: on success
            type: str
            sample: "2013-10-20T19:20:30+01:00"
        time_updated:
            description:
                - The date and time the resource was updated, in the format defined by L(RFC3339,https://tools.ietf.org/html/rfc3339).
                - "Example: `2016-08-25T21:10:29.600Z`"
            returned: on success
            type: str
            sample: "2013-10-20T19:20:30+01:00"
    sample: {
        "id": "ocid1.resource.oc1..xxxxxxEXAMPLExxxxxx",
        "compartment_id": "ocid1.compartment.oc1..xxxxxxEXAMPLExxxxxx",
        "hpc_island_id": "ocid1.hpcisland.oc1..xxxxxxEXAMPLExxxxxx",
        "network_block_ids": [],
        "defined_tags": {'Operations': {'CostCenter': 'US'}},
        "display_name": "display_name_example",
        "freeform_tags": {'Department': 'Finance'},
        "instance_pools": [{
            "id": "ocid1.resource.oc1..xxxxxxEXAMPLExxxxxx",
            "compartment_id": "ocid1.compartment.oc1..xxxxxxEXAMPLExxxxxx",
            "defined_tags": {'Operations': {'CostCenter': 'US'}},
            "display_name": "display_name_example",
            "freeform_tags": {'Department': 'Finance'},
            "instance_configuration_id": "ocid1.instanceconfiguration.oc1..xxxxxxEXAMPLExxxxxx",
            "lifecycle_state": "PROVISIONING",
            "placement_configurations": [{
                "availability_domain": "Uocm:PHX-AD-1",
                "primary_subnet_id": "ocid1.primarysubnet.oc1..xxxxxxEXAMPLExxxxxx",
                "fault_domains": [],
                "secondary_vnic_subnets": [{
                    "display_name": "display_name_example",
                    "subnet_id": "ocid1.subnet.oc1..xxxxxxEXAMPLExxxxxx"
                }]
            }],
            "size": 56,
            "time_created": "2013-10-20T19:20:30+01:00",
            "load_balancers": [{
                "id": "ocid1.resource.oc1..xxxxxxEXAMPLExxxxxx",
                "instance_pool_id": "ocid1.instancepool.oc1..xxxxxxEXAMPLExxxxxx",
                "load_balancer_id": "ocid1.loadbalancer.oc1..xxxxxxEXAMPLExxxxxx",
                "backend_set_name": "backend_set_name_example",
                "port": 56,
                "vnic_selection": "vnic_selection_example",
                "lifecycle_state": "ATTACHING"
            }],
            "instance_display_name_formatter": "instance_display_name_formatter_example",
            "instance_hostname_formatter": "instance_hostname_formatter_example"
        }],
        "placement_configuration": {
            "availability_domain": "Uocm:PHX-AD-1",
            "placement_constraint": "SINGLE_TIER",
            "primary_subnet_id": "ocid1.primarysubnet.oc1..xxxxxxEXAMPLExxxxxx",
            "secondary_vnic_subnets": [{
                "display_name": "display_name_example",
                "subnet_id": "ocid1.subnet.oc1..xxxxxxEXAMPLExxxxxx"
            }]
        },
        "lifecycle_state": "PROVISIONING",
        "time_created": "2013-10-20T19:20:30+01:00",
        "time_updated": "2013-10-20T19:20:30+01:00"
    }
"""

from ansible_collections.oracle.oci.plugins.module_utils import (
    oci_common_utils,
    oci_wait_utils,
)
from ansible_collections.oracle.oci.plugins.module_utils.oci_resource_utils import (
    OCIActionsHelperBase,
    OCIAnsibleModule,
    get_custom_class,
)

try:
    from oci.core import ComputeManagementClient
    from oci.core.models import ChangeClusterNetworkCompartmentDetails

    HAS_OCI_PY_SDK = True
except ImportError:
    HAS_OCI_PY_SDK = False


class ClusterNetworkActionsHelperGen(OCIActionsHelperBase):
    """
    Supported actions:
        change_compartment
    """

    @staticmethod
    def get_module_resource_id_param():
        return "cluster_network_id"

    def get_module_resource_id(self):
        return self.module.params.get("cluster_network_id")

    def get_get_fn(self):
        return self.client.get_cluster_network

    def get_resource(self):
        return oci_common_utils.call_with_backoff(
            self.client.get_cluster_network,
            cluster_network_id=self.module.params.get("cluster_network_id"),
        )

    def change_compartment(self):
        action_details = oci_common_utils.convert_input_data_to_model_class(
            self.module.params, ChangeClusterNetworkCompartmentDetails
        )
        return oci_wait_utils.call_and_wait(
            call_fn=self.client.change_cluster_network_compartment,
            call_fn_args=(),
            call_fn_kwargs=dict(
                cluster_network_id=self.module.params.get("cluster_network_id"),
                change_cluster_network_compartment_details=action_details,
            ),
            waiter_type=oci_wait_utils.NONE_WAITER_KEY,
            operation="{0}_{1}".format(
                self.module.params.get("action").upper(),
                oci_common_utils.ACTION_OPERATION_KEY,
            ),
            waiter_client=self.get_waiter_client(),
            resource_helper=self,
            wait_for_states=self.get_action_desired_states(
                self.module.params.get("action")
            ),
        )


ClusterNetworkActionsHelperCustom = get_custom_class(
    "ClusterNetworkActionsHelperCustom"
)


class ResourceHelper(ClusterNetworkActionsHelperCustom, ClusterNetworkActionsHelperGen):
    pass


def main():
    module_args = oci_common_utils.get_common_arg_spec(
        supports_create=False, supports_wait=False
    )
    module_args.update(
        dict(
            cluster_network_id=dict(aliases=["id"], type="str", required=True),
            compartment_id=dict(type="str", required=True),
            action=dict(type="str", required=True, choices=["change_compartment"]),
        )
    )

    module = OCIAnsibleModule(argument_spec=module_args, supports_check_mode=True)

    if not HAS_OCI_PY_SDK:
        module.fail_json(msg="oci python sdk required for this module.")

    resource_helper = ResourceHelper(
        module=module,
        resource_type="cluster_network",
        service_client_class=ComputeManagementClient,
        namespace="core",
    )

    result = resource_helper.perform_action(module.params.get("action"))

    module.exit_json(**result)


if __name__ == "__main__":
    main()
